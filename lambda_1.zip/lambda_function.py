# encoding: utf-8
'''
抓證交所網站資料 1/3
下載股票資料,並存檔原始資料到S3
'''
from __future__ import print_function
import logging
import time
import boto3
import urllib3
import json

# logging module
LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)  # 只輸出INFO & 以上等級的log

#  GLOBAL CONSTANT
OBJ_S3 = boto3.resource('s3')
S_BUCKET = 'stock-tim'  # 放股票資料的s3 bucket,需先建好

# Create a urllib3 PoolManager
http = urllib3.PoolManager()

def lambda_handler(event, context):
    '''
    entry point (lambda)
    '''

    lst_stock = [
        '2330', #台積電
        '2002'  #中鋼
    ]
    
    lst_period = [
        '20200101',  # 年月
        '20200201',  # 年月
        '20200301',  # 年月
        '20200401',  # 年月
        '20200501'   # 年月 
    ]
    for s_stock in lst_stock:
        for s_period in lst_period:
            # URL
            s_url = r'https://www.twse.com.tw/rwd/zh/afterTrading/STOCK_DAY?date=%s&stockNo=%s&response=json' % (s_period, s_stock)
       
            # Fetch
            s_content = fetcher(s_url)

            # Upload to S3
            if s_content is not None:
                # 檔名為unix_timestamp命名
                s_object_name = '%s.json' % int(time.time() * 1000)

                # upload
                s3_put_object_from_string(
                    s_content, s_object_name)  # 上傳檔案_來源: 字串

    return None

def fetcher(s_url):
    '''
    回傳指定url的 body內容
    '''
    # Make a Request
    try:
        response = http.request('GET', s_url)
        if response.status == 200:
            return response.data.decode('utf-8')
        else:
            # 抓網頁失敗的處理
            LOGGER.warning('request fail ! status_code:' + str(response.status))
            return None
    except urllib3.exceptions.HTTPError as e:
        LOGGER.error(f"HTTP error occurred: {e}")
        return None

def s3_put_object_from_string(s_str, s_object_name):
    '''
    上傳到S3,  來源: 字串
    '''
    # string
    s_str = s_str.encode('utf-8')

    # upload
    OBJ_S3.Object(S_BUCKET, s_object_name).put(Body=s_str)

    # log
    LOGGER.info('object_name: ' + s_object_name)
    return None

if __name__ == '__main__':
    '''
    entry point
    '''
    lambda_handler(None, None)