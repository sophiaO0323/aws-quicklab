import json
import logging
import boto3
from decimal import Decimal
import decimal

# 設置日誌
LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)

# 全局常量
DYNAMODB = boto3.resource('dynamodb', region_name='us-east-1')
TABLE = DYNAMODB.Table('stock')
S3 = boto3.client('s3')

def lambda_handler(event, context):
    """Lambda 函數入口點"""
    try:
        # 從 S3 事件中獲取文件內容
        content = get_file_content(event)
        
        # 解析 JSON 內容
        stock_data = parse_json_content(content)
        
        # 將數據保存到 DynamoDB
        save_to_dynamodb(stock_data)
        
        LOGGER.info("處理完成")
        return {"statusCode": 200, "body": json.dumps("數據處理成功")}
    except Exception as e:
        LOGGER.error(f"處理過程中發生錯誤: {str(e)}")
        return {"statusCode": 500, "body": json.dumps("處理過程中發生錯誤")}

def get_file_content(event):
    """從 S3 事件中獲取文件內容"""
    try:
        bucket = event['Records'][0]['s3']['bucket']['name']
        key = event['Records'][0]['s3']['object']['key']
        
        LOGGER.info(f"嘗試從 S3 獲取文件: Bucket={bucket}, Key={key}")
        
        response = S3.get_object(Bucket=bucket, Key=key)
        return response['Body'].read().decode('utf-8')
    except Exception as e:
        LOGGER.error(f"從 S3 獲取文件時發生錯誤: Bucket={bucket}, Key={key}")
        LOGGER.error(f"錯誤詳情: {str(e)}")
        raise

def parse_json_content(content):
    """解析 JSON 內容"""
    data = json.loads(content)
    return {
        'stock_id': data['title'].split()[1],  # 從標題中提取股票代碼
        'stock_name': data['title'].split()[2], # 從標題中提取股票名稱
        'data': data['data']
    }

def save_to_dynamodb(stock_data):
    """將數據保存到 DynamoDB"""
    stock_id = stock_data['stock_id']
    stock_name = stock_data['stock_name']
    success_count = 0
    
    for item in stock_data['data']:
        try:
            # Clean numeric values by removing commas and spaces
            volume_str = item[1].replace(',', '').strip()
            amount_str = item[2].replace(',', '').strip()
            open_str = item[3].replace(',', '').strip()
            high_str = item[4].replace(',', '').strip()
            low_str = item[5].replace(',', '').strip()
            close_str = item[6].replace(',', '').strip()
            transactions_str = item[8].replace(',', '').strip()

            # Convert to appropriate types
            volume = int(volume_str) if volume_str else 0
            amount = Decimal(amount_str) if amount_str else Decimal('0')
            open_price = Decimal(open_str) if open_str else Decimal('0')
            high = Decimal(high_str) if high_str else Decimal('0')
            low = Decimal(low_str) if low_str else Decimal('0')
            close = Decimal(close_str) if close_str else Decimal('0')
            transactions = int(transactions_str) if transactions_str else 0

            # Log the cleaned values for debugging
            LOGGER.info(f"處理數據: volume={volume}, amount={amount}, open={open_price}, high={high}, low={low}, close={close}")

            TABLE.put_item(
                Item={
                    'id': f"{stock_id}_{item[0]}",
                    'stockid': stock_id,
                    'stockname': stock_name,
                    'date': item[0],
                    'volume': volume,
                    'amount': amount,
                    'open': open_price,
                    'high': high,
                    'low': low,
                    'close': close,
                    'change': item[7],
                    'transactions': transactions
                }
            )
            success_count += 1
            LOGGER.info(f"成功保存記錄: {stock_id}_{item[0]}")
            
        except (ValueError, decimal.InvalidOperation) as e:
            LOGGER.error(f"數據轉換錯誤: {str(e)}, 原始數據: {item}")
            LOGGER.error(f"轉換失敗的值: volume_str={volume_str}, amount_str={amount_str}, open_str={open_str}")
            # 不要使用 continue，而是設置默認值
            try:
                TABLE.put_item(
                    Item={
                        'id': f"{stock_id}_{item[0]}",
                        'stockid': stock_id,
                        'stockname': stock_name,
                        'date': item[0],
                        'volume': 0,
                        'amount': Decimal('0'),
                        'open': Decimal('0'),
                        'high': Decimal('0'),
                        'low': Decimal('0'),
                        'close': Decimal('0'),
                        'change': item[7],
                        'transactions': 0
                    }
                )
                success_count += 1
                LOGGER.info(f"使用默認值保存記錄: {stock_id}_{item[0]}")
            except Exception as db_error:
                LOGGER.error(f"保存默認值時發生錯誤: {str(db_error)}")
                
        except Exception as e:
            LOGGER.error(f"保存記錄時發生錯誤: {str(e)}, 原始數據: {item}")
    
    LOGGER.info(f"成功保存 {success_count} 條記錄到 DynamoDB")
